<div class="row">
	<div class="col m 12">
		<h5>Sistem Informasi Perpustakaan Labuhanbatu</h5>
	</div>
</div>

<div class="row">
	<div class="col m6">
		<div class="card-panel teal darken-2 white-text">
			<h6><b>Visi</b></h6>
			<p>
				Visi merupakan pandangan mengenai masa depan yang dianggap ideal untuk dicapai. Suwarno (2011: 18) menyebutkan bahwa visi perpustakaan pada umumnya untuk mewujudkan masyarakat informasi atau masyarakat yang cerdas.
			</p><br>
			<h6><b>Misi</b></h6>
			<li>
				Menciptakan dan memantapkan kebiasaan membaca masyarakat sesuai dengan jenis perpustakaan dan pemakainya.
			</li>
			<li>
				Mendukung pendidikan perorangan secara mandiri maupun pendidikan formal pada semua jenjang.
			</li>
			<li>
				Meningkatkan kesadaran terhadap warisan budaya, apresiasi seni, dan hasil temuan ilmiah.
			</li>
			<li>
				Memberikan kemudahan kepada pengembangan informasi peningkatan ilmu pengetahuan dan keterampilan.
			</li>
		</div>
	</div>
    <div class="col m6">
        <div class="card-panel teal darken-2 white-text">
            <h6><b>Identitas Perpustakaan</b></h6><hr>
            <p>
                Library User Education Services were again implemented by the Public Library, Medan City Library and Archives Service. This activity took place on Tuesday, April 9, 2019 at the Medan City Library Hall. This time the library invited participants consisting of 3 schools in the city of Medan, namely; SMP Negeri 23 Medan, SMP Harapan I Medan, and SMP Private Anugrah Harapan Bangsa. During the activity, Mr. Irfan Syarif Siregar, M.Si as Ka. The field of collection development, service and conservation of library materials provides direction and motivation to participants, because the existence of the Medan City Public Library in the midst of the community can increase interest in reading and increase knowledge..
            </p>
        </div>
    </div>
</div>
